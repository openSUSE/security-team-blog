Reproducer for a (nearly) arbitrary file deletion attack vector in the
`seunshare` setuid-root binary from the SELinux policycoreutils sandbox tools
version 3.10.

The `rm_rf()` function in seunshare is lacking an `O_NOFOLLOW` flag in
the call to `openat()`. This exploit attempts to exploit this race condition.

The C++ program `sedelete` found in this tarball performs the core exploit
logic, while the wrapper script `sedelete-wrapper.sh` runs the exploit in a
loop until it succeeds. You need to select a root-owned directory to delete
e.g. `/etc/`

*** WARNING *** In the case of success your system will be broken without
anything left in /etc. Only do this on a test system or with a directory you
can spare.

Invoke the wrapper script like this:

```sh
./sedelete-wrapper.sh /path/to/delete 5500
```

The integer argument is a delay in microseconds which tunes the exploit to
get it closer to winning the race condition. In the output you will see how
many dirs the exploit logic is able to replace by symbolic links:

```sh
replaced 0 links
sandbox dir fully deleted
>>> exploit failed <<<
Attempting to delete /etc via /usr/sbin/seunshare
executing "/usr/sbin/seunshare -t /home/mgerstner/sedeleter-tmp --
/usr/bin/touch /tmp/a-new-file "
replaced 4 links
sandbox dir fully deleted
>>> exploit failed <<<
Attempting to delete /etc via /usr/sbin/seunshare
executing "/usr/sbin/seunshare -t /home/mgerstner/sedeleter-tmp --
/usr/bin/touch /tmp/a-new-file "
replaced 0 links
```

When the exploit never manages to replace the dirs then the exploit logic is
too slow, when it always manages to replace the dirs then it is too fast. Tune
the delay until you see a good mixture of replaced 0 / 2 / 4 symbolic links,
which means that the exploit is closing in on the race window. Then it is
usually only a matter of a couple of seconds or sometimes a minute for the
exploit to succeed.

You can set the `SEDELETER_VERBOSE` environment variable to increase verbosity
for analyzing what is going on.
